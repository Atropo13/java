package fp.universidad.tipos;

public record Asignaturas(String nombre, String codigo, Double creditos,TipoAsignatura tipoAsignatura,  Integer curso) {
	

	public String getAcronimo() {
return null;
}
	
	public String toString() {
		return "("+ codigo + ") " + nombre;
	}
}
