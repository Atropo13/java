package fp.universidad.tipos;

import java.time.LocalDate;

public class Persona{
//Atributos
	private String dni;
	private String nombre;
	private String apellido;
	private LocalDate fechaNacimiento; 
	private String  email;
}

//Constructor
public Persona(String dni, String nombre, String apellido, LocalDate fechaNaciiento, String email) {
	
}