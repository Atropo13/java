package fp.universidad.tipos.test;
import fp.universidad.tipos.*;
public class TestAsignatura {

	public static void main(String[] args) {
		Asignaturas a = new Asignaturas("Fundamentos de Programación","000260",12.0, TipoAsignatura.ANUAL,  1 );
		
		System.out.println(a);
				
	}

}
