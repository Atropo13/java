package fp.universidad.tipos.test;

public class PersonaTest {

	public static void main(String[] args) {
		String dni = "44444444M";
		String nombre = "Maria";
		String 

	}

}
