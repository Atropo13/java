package fp.universidad.tipos;

public enum TipoAsignatura {ANUAL, PRIMER_CUATRIMESTRE, SEGUNDO_CUATRIMESTRE

}
