package fp.universidad.tipos;

public class Espacio {

}
